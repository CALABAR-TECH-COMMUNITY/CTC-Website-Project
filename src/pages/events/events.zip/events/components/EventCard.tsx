import Vector from "assets/images/Vector.png";

interface Props {
  image: string;
  month: string;
  date: string;
  superscript: string;
  title: string;
  desc: string;
  location: string;
}

const EventCard = (props: Props): JSX.Element => {
  return (
    <div className="bg-white shadow-eventCardShadow">
      <img
        draggable={false}
        className="h-56 w-full object-cover"
        src={props.image}
        alt={props.title}
      />

      <div>
        <time dateTime={props.date + props.month}>
          <div>{props.date}</div>
          <data>{props.month}</data>
        </time>

        <div className="h-[90%] w-1 bg-appGray400" />

        <article>
          <p>Navigating your way through tech</p>

          <p>Get to meet with professionals...</p>

          <span>Calabar, Nigeria.</span>
        </article>
      </div>
    </div>
  );
};

export default EventCard;
